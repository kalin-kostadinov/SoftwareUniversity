package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dtos.xmls.SellerImportDto;
import softuni.exam.models.dtos.xmls.SellerImportRootDto;
import softuni.exam.models.entities.Rating;
import softuni.exam.models.entities.Seller;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.SellerService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class SellerServiceImpl implements SellerService {

    private final static String SELLER_IMPORT = "src/main/resources/files/xml/sellers.xml";

    private final SellerRepository sellerRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    @Autowired
    public SellerServiceImpl(SellerRepository sellerRepository, XmlParser xmlParser
            , ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.sellerRepository = sellerRepository;
        this.xmlParser = xmlParser;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {
        return this.sellerRepository.count() > 0;
    }

    @Override
    public String readSellersFromFile() throws IOException {
        return String.join(" ", Files.readAllLines(Path.of(SELLER_IMPORT)));
    }

    @Override
    public String importSellers() throws IOException, JAXBException {

        StringBuilder sb = new StringBuilder();

        SellerImportRootDto root = this.xmlParser.parseXml(SellerImportRootDto.class, SELLER_IMPORT);

        for (SellerImportDto dto : root.getSellers()) {
            Rating rating;
            try {
               rating = Rating.valueOf(dto.getRating());
           } catch (Exception e) {
               sb.append("Invalid seller").append(System.lineSeparator());
               continue;
           }

            Optional<Seller> byEmail = this.sellerRepository.findByEmail(dto.getEmail());

            if (this.validationUtil.isValid(dto) && byEmail.isEmpty()) {

                // make enum validation for rating
                Seller seller = this.modelMapper.map(dto, Seller.class);
                seller.setRating(rating);
                this.sellerRepository.saveAndFlush(seller);

                sb.append(String.format("Successfully import seller %s - %s"
                        , dto.getLastName(), dto.getEmail()))
                        .append(System.lineSeparator());
            } else {
                sb.append("Invalid selled").append(System.lineSeparator());
            }


        }

        return sb.toString();
    }
}
