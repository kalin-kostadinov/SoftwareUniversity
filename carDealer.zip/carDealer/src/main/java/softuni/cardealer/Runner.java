package softuni.cardealer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;
import softuni.cardealer.services.*;

@Component
public class Runner implements CommandLineRunner {

    private final ConfigurableApplicationContext applicationContext;
    private final SupplierService supplierService;
    private final PartService partService;
    private final CarService carService;
    private final CustomerService customerService;
    private final SaleService saleService;

    @Autowired
    public Runner(ConfigurableApplicationContext applicationContext, SupplierService supplierService, PartService partService, CarService carService, CustomerService customerService, SaleService saleService) {
        this.applicationContext = applicationContext;
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
        this.customerService = customerService;
        this.saleService = saleService;
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println("Greetings, fellow coder!");
        System.out.println();
        System.out.println("Please uncomment seeding functions and/or query export functions!");



//        this.supplierService.seedSuppliers();
//        this.partService.seedParts();
//        this.carService.seedCars();
//        this.customerService.seedCustomers();
//        this.saleService.seedSales();

//        System.out.println(this.customerService.orderedCustomers());
//        System.out.println(this.carService.carsFromMakeToyota("Toyota"));
//        System.out.println(this.supplierService.localSuppliers());
//        System.out.println(this.carService.carsWithTheirListOfParts());
//        System.out.println(this.customerService.totalSalesByCustomer());
        System.out.println(this.saleService.salesWithAppliedDiscount());


        applicationContext.close();
    }
}
