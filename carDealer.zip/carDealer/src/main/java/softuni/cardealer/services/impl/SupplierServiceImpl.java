package softuni.cardealer.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.cardealer.domain.dtos.exports.LocalSuppliersDto;
import softuni.cardealer.domain.dtos.exports.LocalSuppliersRootDto;
import softuni.cardealer.domain.dtos.imports.SupplierImportDto;
import softuni.cardealer.domain.dtos.imports.SupplierImportRootDto;
import softuni.cardealer.domain.entities.Supplier;
import softuni.cardealer.domain.repositories.SupplierRepository;
import softuni.cardealer.services.SupplierService;
import softuni.cardealer.utils.XmlParser;

import javax.xml.bind.JAXBException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SupplierServiceImpl implements SupplierService {

    private final static String SUPPLIERS_PATH = "src/main/resources/xml/imports/suppliers.xml";
    private final static String LOCAL_SUPPLIERS = "src/main/resources/xml/exports/local-suppliers.xml";

    private final SupplierRepository supplierRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;


    @Autowired
    public SupplierServiceImpl(SupplierRepository supplierRepository, XmlParser xmlParser, ModelMapper modelMapper) {
        this.supplierRepository = supplierRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }


    @Override
    public void seedSuppliers() throws  JAXBException {

        SupplierImportRootDto supplierImportRootDto = this.xmlParser.parseXml(SupplierImportRootDto.class, SUPPLIERS_PATH);

        for (SupplierImportDto dtoSupplier : supplierImportRootDto.getSuppliers()) {
            this.supplierRepository.saveAndFlush(this.modelMapper.map(dtoSupplier, Supplier.class));
        }

    }

    @Override

    public String localSuppliers() throws JAXBException {
        LocalSuppliersRootDto root = new LocalSuppliersRootDto();
        root.setSuppliers(new ArrayList<>());

        List<Supplier> supplierList = this.supplierRepository.findAllByImporterIsFalse();
        for (Supplier supplier : supplierList) {
            LocalSuppliersDto dto = this.modelMapper.map(supplier, LocalSuppliersDto.class);
            dto.setPartsCount(supplier.getParts().size());
            root.getSuppliers().add(dto);
        }

        this.xmlParser.exportXml(root, LocalSuppliersRootDto.class, LOCAL_SUPPLIERS);

        return "Successfully written suppliers. Check your resources/export directory";

    }
}
