package softuni.cardealer.services;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface CarService {

    void seedCars() throws Exception;

    String carsFromMakeToyota(String make) throws IOException, JAXBException;

    String carsWithTheirListOfParts() throws IOException, JAXBException;
}
