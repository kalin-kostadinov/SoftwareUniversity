package softuni.cardealer.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.cardealer.domain.dtos.exports.*;
import softuni.cardealer.domain.dtos.imports.CarImportDto;
import softuni.cardealer.domain.dtos.imports.CarImportRootDto;
import softuni.cardealer.domain.entities.Car;
import softuni.cardealer.domain.entities.Part;
import softuni.cardealer.domain.repositories.CarRepository;
import softuni.cardealer.domain.repositories.PartRepository;
import softuni.cardealer.services.CarService;
import softuni.cardealer.utils.XmlParser;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    private final static String CARS_PATH = "src/main/resources/xml/imports/cars.xml";
    private final static String TOYOTA_CARS = "src/main/resources/xml/exports/toyota-cars.xml";
    private final static String CARS_AND_PARTS = "src/main/resources/xml/exports/cars-and-parts.xml";

    private final CarRepository carRepository;
    private final PartRepository partRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    @Autowired
    public CarServiceImpl(CarRepository carRepository, PartRepository partRepository, ModelMapper modelMapper, XmlParser xmlParser) {
        this.carRepository = carRepository;
        this.partRepository = partRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }


    @Override
    @Transactional
    public void seedCars() throws Exception {
        CarImportRootDto carImportRootDto = this.xmlParser.parseXml(CarImportRootDto.class, CARS_PATH);

        for (CarImportDto carImportDto : carImportRootDto.getCars()) {
            Car car = this.modelMapper.map(carImportDto, Car.class);
            car.setParts(getRandomParts());
            this.carRepository.saveAndFlush(car);
        }

    }

    @Override
    public String carsFromMakeToyota(String make) throws  JAXBException {
        List<ToyotaCarsDto> carsDtoList = this.carRepository
                .findAllByMakeOrderByModelAscTravelledDistanceDesc("Toyota").stream()
                .map(c -> this.modelMapper.map(c, ToyotaCarsDto.class)).collect(Collectors.toList());

        ToyotaCarsRootDto dto = new ToyotaCarsRootDto();
        dto.setCars(carsDtoList);

        this.xmlParser.exportXml(dto, ToyotaCarsRootDto.class, TOYOTA_CARS);


        return "Successfully written cars. Check your resources/exports directory";
    }

    @Override
    public String carsWithTheirListOfParts() throws JAXBException {
        List<Car> all = this.carRepository.findAll();

        CarsAndPartsRootDto carRootDto = new CarsAndPartsRootDto();
        List<CarsAndPartsCarDto> carDtoList = new ArrayList<>();

        for (Car car : all) {
            CarsAndPartsCarDto carDto = this.modelMapper.map(car, CarsAndPartsCarDto.class);

            CarsAndPartsPartRootDto partsRootDto = new CarsAndPartsPartRootDto();
            List<CarsAndPartsPartDto> partsDtoList = new ArrayList<>();

            for (Part part : car.getParts()) {
                CarsAndPartsPartDto partDto = this.modelMapper.map(part, CarsAndPartsPartDto.class);
                partsDtoList.add(partDto);
            }
            partsRootDto.setParts(partsDtoList);
            carDto.setParts(partsRootDto);
            carDtoList.add(carDto);
        }

        carRootDto.setCars(carDtoList);
        this.xmlParser.exportXml(carRootDto, CarsAndPartsRootDto.class, CARS_AND_PARTS);

        return "Successfully written cars. Check your resources/exports directory";
    }

    private Set<Part> getRandomParts() throws Exception {

        Set<Part> parts = new HashSet<>();

        for (int i = 0; i < 10; i++) {
            Part part = this.getRandomPart();
            parts.add(part);
        }
        return parts;
    }

    private Part getRandomPart() throws Exception {

        Random random = new Random();

        int index = random.nextInt((int) this.partRepository.count()) + 1;
        Optional<Part> part = this.partRepository.findById((long) index);

        if (part.isPresent()) {
            return part.get();
        } else {
            throw new Exception("Invalid supplier!");
        }
    }
}
