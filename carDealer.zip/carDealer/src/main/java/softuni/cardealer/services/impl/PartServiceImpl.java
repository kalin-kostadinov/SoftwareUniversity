package softuni.cardealer.services.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.cardealer.domain.dtos.imports.PartImportDto;
import softuni.cardealer.domain.dtos.imports.PartImportRootDto;
import softuni.cardealer.domain.entities.Part;
import softuni.cardealer.domain.entities.Supplier;
import softuni.cardealer.domain.repositories.PartRepository;
import softuni.cardealer.domain.repositories.SupplierRepository;
import softuni.cardealer.services.PartService;
import softuni.cardealer.utils.XmlParser;

import java.util.Optional;
import java.util.Random;

@Service
public class PartServiceImpl implements PartService {

    private final static String PARTS_PATH = "src/main/resources/xml/imports/parts.xml";

    private final PartRepository partRepository;
    private final SupplierRepository supplierRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    @Autowired
    public PartServiceImpl(PartRepository partRepository, SupplierRepository supplierRepository, ModelMapper modelMapper, Gson gson, XmlParser xmlParser) {
        this.partRepository = partRepository;
        this.supplierRepository = supplierRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public void seedParts() throws Exception {
        PartImportRootDto partImportRootDto = this.xmlParser.parseXml(PartImportRootDto.class, PARTS_PATH);

        for (PartImportDto part : partImportRootDto.getParts()) {
            Part part1 = this.modelMapper.map(part, Part.class);
            part1.setSupplier(getRandomSupplier());
            this.partRepository.saveAndFlush(part1);
        }


    }

    private Supplier getRandomSupplier() throws Exception {

        Random random = new Random();

        int index = random.nextInt((int) this.supplierRepository.count()) + 1;
        Optional<Supplier> supplier = this.supplierRepository.findById((long) index);

        if (supplier.isPresent()) {
            return supplier.get();
        } else {
            throw new Exception("Invalid supplier!");
        }
    }
}
