package softuni.cardealer.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.cardealer.domain.dtos.exports.CustomerExportDto;
import softuni.cardealer.domain.dtos.exports.CustomerExportRootDto;
import softuni.cardealer.domain.dtos.exports.CustomersTotalDto;
import softuni.cardealer.domain.dtos.exports.CustomersTotalRootDto;
import softuni.cardealer.domain.dtos.imports.CustomerImportDto;
import softuni.cardealer.domain.dtos.imports.CustomerImportRootDto;
import softuni.cardealer.domain.entities.Customer;
import softuni.cardealer.domain.entities.Part;
import softuni.cardealer.domain.entities.Sale;
import softuni.cardealer.domain.repositories.CustomerRepository;
import softuni.cardealer.services.CustomerService;
import softuni.cardealer.utils.XmlParser;

import javax.xml.bind.JAXBException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final static String CUSTOMER_PATH = "src/main/resources/xml/imports/customers.xml";
    private final static String ORDERED_CUSTOMERS = "src/main/resources/xml/exports/ordered-customers.xml";
    private final static String CUSTOMERS_TOTAL_SALES = "src/main/resources/xml/exports/customers-total-sales.xml";

    private final CustomerRepository customerRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;


    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository, ModelMapper modelMapper, XmlParser xmlParser) {
        this.customerRepository = customerRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public void seedCustomers() throws  JAXBException {

        CustomerImportRootDto customerImportRootDto =
                this.xmlParser.parseXml(CustomerImportRootDto.class, CUSTOMER_PATH);

        for (CustomerImportDto dtoCustomer : customerImportRootDto.getCustomers()) {
            this.customerRepository.saveAndFlush(this.modelMapper.map(dtoCustomer, Customer.class));
        }
    }

    @Override
    public String orderedCustomers() throws  JAXBException {

        Set<Customer> customerSet = this.customerRepository.getAllByOrderByBirthDateAscYoungDriverAsc();

        CustomerExportRootDto root = new CustomerExportRootDto();
        root.setCustomers(new ArrayList<>());

        for (Customer customer : customerSet) {
            CustomerExportDto dto = this.modelMapper.map(customer, CustomerExportDto.class);
            root.getCustomers().add(dto);
        }

        this.xmlParser.exportXml(root,CustomerExportRootDto.class, ORDERED_CUSTOMERS);

        return "Successfully written customers. Check your resources/exports directory";
    }

    @Override
    public String totalSalesByCustomer() throws JAXBException {

        List<Customer> customers = this.customerRepository.totalSales();

        CustomersTotalRootDto rootDto = new CustomersTotalRootDto();
        List<CustomersTotalDto> dtoList = new ArrayList<>();

        for (Customer customer : customers) {
            CustomersTotalDto dto = new CustomersTotalDto();
            dto.setName(customer.getName());
            dto.setBoughtCars(customer.getSales().size());

            double moneySpent = 0;
            for (Sale sale : customer.getSales()) {
                for (Part part : sale.getCar().getParts()) {
                    moneySpent += part.getPrice().doubleValue();
                }
            }
            dto.setSpentMoney(moneySpent);
            dtoList.add(dto);
        }

        dtoList = dtoList.stream().sorted((c1, c2) -> Double.compare(c2.getSpentMoney(), c1.getSpentMoney())).collect(Collectors.toList());

        rootDto.setCustomers(dtoList);
        xmlParser.exportXml(rootDto, CustomersTotalRootDto.class, CUSTOMERS_TOTAL_SALES);

        return "Successfully written customers. Check your resources/exports directory";
    }
}
