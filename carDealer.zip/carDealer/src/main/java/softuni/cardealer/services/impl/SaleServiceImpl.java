package softuni.cardealer.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.cardealer.domain.dtos.exports.SaleCarDto;
import softuni.cardealer.domain.dtos.exports.SaleDto;
import softuni.cardealer.domain.dtos.exports.SaleRootDto;
import softuni.cardealer.domain.entities.*;
import softuni.cardealer.domain.repositories.CarRepository;
import softuni.cardealer.domain.repositories.CustomerRepository;
import softuni.cardealer.domain.repositories.SaleRepository;
import softuni.cardealer.services.SaleService;
import softuni.cardealer.utils.XmlParser;

import javax.xml.bind.JAXBException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class SaleServiceImpl implements SaleService {

    private final static String SALES_DISCOUNTS = "src/main/resources/xml/exports/sales-discounts.xml";

    private final SaleRepository saleRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;
    private final XmlParser xmlParser;

    @Autowired
    public SaleServiceImpl(SaleRepository saleRepository, CarRepository carRepository, CustomerRepository customerRepository, XmlParser xmlParser) {
        this.saleRepository = saleRepository;
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
        this.xmlParser = xmlParser;
    }


    @Override
    public void seedSales() {

        for (int i = 0; i < 100; i++) {
            Sale sale = new Sale();
            sale.setCar(getRandomCar());
            sale.setCustomer(getRandomCustomer());
            int discount = getRandomDiscount();
            if (sale.getCustomer().isYoungDriver()) {
                discount = discount + 5;
            }
            sale.setDiscount(discount);
            this.saleRepository.saveAndFlush(sale);
        }

    }

    @Override
    public String salesWithAppliedDiscount() throws JAXBException {

        List<Sale> all = this.saleRepository.findAll();

        SaleRootDto root = new SaleRootDto();

        List<SaleDto> dtoList = new ArrayList<>();

        for (Sale sale : all) {
            SaleDto saleDto = new SaleDto();
            SaleCarDto carDto = new SaleCarDto();

            carDto.setMake(sale.getCar().getMake());
            carDto.setModel(sale.getCar().getModel());
            carDto.setTravelledDistance(sale.getCar().getTravelledDistance());
            saleDto.setCar(carDto);

            saleDto.setCustomerName(sale.getCustomer().getName());
            saleDto.setDiscount(1.0*sale.getDiscount()/100);

            double price = 0;

            for (Part part : sale.getCar().getParts()) {
                price += part.getPrice().doubleValue();
            }
            saleDto.setPrice(price);
            saleDto.setPriceWithDiscount(price - (price* 1.0*sale.getDiscount()/100));
            dtoList.add(saleDto);
        }
        root.setSales(dtoList);

        this.xmlParser.exportXml(root, SaleRootDto.class, SALES_DISCOUNTS);

        return "Successfully written sales. Check your resources/exports directory";



    }

    private int getRandomDiscount() {
        List<Integer> discountRange = new ArrayList<>();

        discountRange.add(0);
        discountRange.add(5);
        discountRange.add(10);
        discountRange.add(15);
        discountRange.add(20);
        discountRange.add(30);
        discountRange.add(40);
        discountRange.add(50);

        Random random = new Random();

        int index = random.nextInt(7);
        return discountRange.get(index);
    }

    private Car getRandomCar() {
        Random random = new Random();
        long id = (long) random.nextInt((int)this.carRepository.count()) +1;
        return  this.carRepository.findById(id).get();
    }

    private Customer getRandomCustomer() {
        Random random = new Random();
        long id = (long) random.nextInt((int)this.customerRepository.count()) +1;
        return  this.customerRepository.findById(id).get();
    }
}
