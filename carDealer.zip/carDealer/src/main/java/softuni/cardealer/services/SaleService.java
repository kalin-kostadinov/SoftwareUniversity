package softuni.cardealer.services;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface SaleService {

    void seedSales();

    String salesWithAppliedDiscount() throws IOException, JAXBException;
}
