package softuni.cardealer.domain.dtos.exports;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "parts")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarsAndPartsPartRootDto {

    @XmlElement(name = "part")
    private List<CarsAndPartsPartDto> parts;

    public CarsAndPartsPartRootDto() {
    }

    public List<CarsAndPartsPartDto> getParts() {
        return parts;
    }

    public void setParts(List<CarsAndPartsPartDto> parts) {
        this.parts = parts;
    }
}
