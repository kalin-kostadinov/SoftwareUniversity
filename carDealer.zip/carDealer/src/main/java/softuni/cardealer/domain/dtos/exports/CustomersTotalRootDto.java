package softuni.cardealer.domain.dtos.exports;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "customers")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomersTotalRootDto {

    @XmlElement(name = "customer")
    private List<CustomersTotalDto> customers;

    public CustomersTotalRootDto() {
    }

    public List<CustomersTotalDto> getCustomers() {
        return customers;
    }

    public void setCustomers(List<CustomersTotalDto> customers) {
        this.customers = customers;
    }
}
