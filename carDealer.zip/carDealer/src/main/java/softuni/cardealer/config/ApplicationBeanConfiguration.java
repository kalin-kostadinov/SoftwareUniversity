package softuni.cardealer.config;

import com.google.gson.*;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import softuni.cardealer.utils.XmlParser;
import softuni.cardealer.utils.XmlParserImpl;

import javax.validation.Validation;
import javax.validation.Validator;

@Configuration
public class ApplicationBeanConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public Gson gson() {
        return new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .setPrettyPrinting()
//                .registerTypeAdapter(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
//                    @Override
//                    public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
//                        return LocalDateTime
//                                .parse(json.getAsString(), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));}} )
                .create();
    }

//    @Bean
//    public Validator validator() {return Validation.buildDefaultValidatorFactory().getValidator();}
//
//    @Bean
//    public ValidatorUtil validatorUtil() {return new ValidatorUtilImpl(validator());}


    @Bean
    public XmlParser xmlParser() {
        return new XmlParserImpl();
    }


}
